import './modal';
import '../less/bootstrap.less';
