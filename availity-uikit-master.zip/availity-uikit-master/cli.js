'use strict';

require('./dev');
